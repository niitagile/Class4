import javax.persistence.*;
import java.util.List;

//Bean- A simple class which conatins variables, getter/setter, constructor
@Entity

public class Student {
    @Id

    private int rollno;
    private String studname;
    @OneToMany(targetEntity = Book.class)
    private List<Book> book_issued;

    public List<Book> getBook_issued() {
        return book_issued;
    }

    public void setBook_issued(List<Book> book_issued) {
        this.book_issued = book_issued;
    }

    public int getRollno() {
        return rollno;
    }

    public void setRollno(int rollno) {
        this.rollno = rollno;
    }

    public String getStudname() {
        return studname;
    }

    public void setStudname(String studname) {
        this.studname = studname;
    }
}
