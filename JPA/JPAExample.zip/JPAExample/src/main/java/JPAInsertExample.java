import javax.persistence.*;
public class JPAInsertExample {
    public static void main(String[] args) {
        EntityManagerFactory emf=Persistence.createEntityManagerFactory("StudentDetails");
        EntityManager em=emf.createEntityManager();

        em.getTransaction().begin();

        Student s1=new Student();
        s1.setRollno(1);
        s1.setStudname("Gaurav");

        Student s2=new Student();
        s2.setRollno(2);
        s1.setStudname("Manish");

        Library l1=new Library();
        l1.setL_id(101);
        l1.setL_name("Technical");
        l1.setStudent(s1);



        em.persist(s1);
        em.persist(s2);
        em.persist(l1);


        em.getTransaction().commit();

        emf.close();
        em.close();

    }
}

