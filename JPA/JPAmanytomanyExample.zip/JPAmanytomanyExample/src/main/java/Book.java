import javax.persistence.*;
import java.util.List;

@Entity
public class Book {
    @Id
    int b_id;
    @Column(length=30)
    String b_name;

    public List<Student> getSlist() {
        return slist;
    }

    public void setSlist(List<Student> slist) {
        this.slist = slist;
    }

    @ManyToMany(targetEntity = Student.class)
    List<Student> slist;
    public int getB_id() {
        return b_id;
    }

    public void setB_id(int b_id) {
        this.b_id = b_id;
    }

    public String getB_name() {
        return b_name;
    }

    public void setB_name(String b_name) {
        this.b_name = b_name;
    }
}
