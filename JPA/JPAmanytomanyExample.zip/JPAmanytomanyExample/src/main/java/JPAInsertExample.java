import javax.persistence.*;
import java.util.ArrayList;

public class JPAInsertExample {
    public static void main(String[] args) {
        EntityManagerFactory emf=Persistence.createEntityManagerFactory("StudentDetails");
        EntityManager em=emf.createEntityManager();

        em.getTransaction().begin();

        Student s1=new Student();
        s1.setRollno(34);
        s1.setStudname("Gaurav");

        Student s2=new Student();
        s1.setRollno(35);
        s1.setStudname("Babita");

       Book l1=new Book();
        l1.setB_id(101);
        l1.setB_name("C++");


        Book l2=new Book();
        l2.setB_id(102);
        l2.setB_name("Chemical");
        //Add in List
        ArrayList<Book> list=new ArrayList<>();
        list.add(l1);
        list.add(l2);
        s1.setBook_issued(list);

        ArrayList<Student> slist=new ArrayList<>();
        slist.add(s1);
        slist.add(s2);
        l1.setSlist(slist);

        em.persist(l1);
        em.persist(l2);
       em.persist(s1);
       em.persist(s2);


        em.getTransaction().commit();

        emf.close();
        em.close();

    }
}

