import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;


class CalculatorTest {

    @Test
    void add() {
        assertEquals(5, Calculator.add(2, 2));
    }

    @Test
    void calc() {
        assertEquals(6, Calculator.calcLength("Kavita"));
    }

    @Test
    void div() {

        Exception exception = assertThrows(
                ArithmeticException.class,
                () -> Calculator.div(1, 0));

        assertEquals("/ by zero", exception.getMessage());

        assertTrue(exception.getMessage().contains("zero"));
    }
}