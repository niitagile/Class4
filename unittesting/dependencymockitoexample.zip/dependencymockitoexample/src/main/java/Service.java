interface Service {

	public boolean send(String msg);
}