import java.util.stream.DoubleStream;

public class Calculator {

    static int add(int a, int b){
        return a+b;

    }
    static int calcLength(String name){
        return name.length();
    }
    static int div(int a, int b){
        return a/b;
    }
}
