package com.example.restexample1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestExample1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
