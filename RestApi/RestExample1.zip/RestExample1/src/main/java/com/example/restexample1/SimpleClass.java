package com.example.restexample1;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SimpleClass {
    @RequestMapping("/message")
    public String msg(){
        return "Hello ALl!!!";
    }
}
