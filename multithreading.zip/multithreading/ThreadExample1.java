package multithreading;

public class ThreadExample1 {
    public static void main(String[] args) {
        Thread t=Thread.currentThread();
        System.out.println(t);//main- threadname 5- priorty main-groupname
        System.out.println(t.getId());
        t.setName("Mythread");
        System.out.println(t);
        System.out.println(t.getState());
        System.out.println(t.isAlive());
        System.out.println(t.isDaemon());
    }
}
