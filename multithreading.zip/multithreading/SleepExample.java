package multithreading;

public class SleepExample {
    public static void main(String[] args) {
        try {
            for (int i = 1; i < 3; i++) {
                System.out.println("Hello!!!!!");
                Thread.sleep(2000);
            }
        }
        catch(InterruptedException e){
            e.printStackTrace();
        }
    }
}
