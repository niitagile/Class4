package multithreading;
class MyThread implements Runnable{

    @Override
    public void run() {
        System.out.println("Mythread Run Method");
    }
}
public class RunnableExample {
    public static void main(String[] args) {
       Thread obj=new Thread(new MyThread());
        obj.start();

    }
}
