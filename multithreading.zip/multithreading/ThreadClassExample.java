package multithreading;
class MyThread1 extends Thread{
    public void run(){
        System.out.println("Thread execution");
    }
}
public class ThreadClassExample {
    public static void main(String[] args) {
        new MyThread1().start();
        System.out.println("End of main thread");
    }
}
